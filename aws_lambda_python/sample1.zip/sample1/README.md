http://docs.aws.amazon.com/lambda/latest/dg/python-programming-model-handler-types.html

handler: test.lambda_handler
